import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:hopetsit/controllers/stripe_payment_controller.dart';
import 'package:hopetsit/models/booking_model.dart';
import 'package:hopetsit/utils/app_colors.dart';
import 'package:hopetsit/utils/currency_helper.dart';
import 'package:hopetsit/widgets/app_text.dart';
import 'package:hopetsit/widgets/rounded_text_button.dart';

/// Stripe payment screen for booking payments.
///
/// Session v17 — coloured by provider role:
///   walker  → green  (#16A34A)
///   sitter  → blue   (#2563EB)
///   fallback → app primary
///
/// Provider type is taken from the [providerType] argument when supplied,
/// otherwise derived from `booking.serviceType` (same heuristic as
/// owner_booking_detail_screen.dart). Caller should pass it explicitly when
/// known so that legacy bookings without serviceType still render correctly.
///
/// Now also displays the provider name, service label, and date range so
/// the owner sees exactly what they are about to pay for.
class StripePaymentScreen extends StatelessWidget {
  final BookingModel booking;
  final double totalAmount;
  final String? currency;

  /// Optional explicit provider type ('walker' or 'sitter'). When null, the
  /// type is inferred from `booking.serviceType`.
  final String? providerType;

  const StripePaymentScreen({
    super.key,
    required this.booking,
    required this.totalAmount,
    this.currency,
    this.providerType,
  });

  // ── Role detection (same logic as owner_booking_detail_screen v16.3i) ─────
  static const Color _walkerAccent = Color(0xFF16A34A);
  static const Color _sitterAccent = Color(0xFF2563EB);

  bool get _isWalker {
    final explicit = providerType?.toLowerCase();
    if (explicit == 'walker') return true;
    if (explicit == 'sitter') return false;
    final s = (booking.serviceType ?? '').toLowerCase();
    return s.contains('dog_walking') || s.contains('walking');
  }

  bool get _isSitter {
    final explicit = providerType?.toLowerCase();
    if (explicit == 'sitter') return true;
    if (explicit == 'walker') return false;
    if (_isWalker) return false;
    final s = (booking.serviceType ?? '').toLowerCase();
    return s.contains('sitting') ||
        s.contains('day_care') ||
        s.contains('boarding');
  }

  Color _accent() {
    if (_isWalker) return _walkerAccent;
    if (_isSitter) return _sitterAccent;
    return AppColors.primaryColor;
  }

  String _providerName() {
    final n = booking.sitter.name;
    return n.isNotEmpty ? n : 'provider_unknown'.tr;
  }

  String _serviceLabel() {
    final raw = (booking.serviceType ?? '').trim();
    if (raw.isEmpty) return '';
    // Try a translation key first ("service_dog_walking", "service_house_sitting"…)
    final key = 'service_${raw.toLowerCase().replaceAll(' ', '_')}';
    final translated = key.tr;
    if (translated != key) return translated;
    // Fallback: humanise the raw string ("dog_walking" → "Dog walking").
    return raw
        .replaceAll('_', ' ')
        .replaceAll('-', ' ')
        .trim()
        .split(' ')
        .where((w) => w.isNotEmpty)
        .map((w) => w[0].toUpperCase() + w.substring(1))
        .join(' ');
  }

  String _dateLabel() {
    // booking.date is required ("YYYY-MM-DD"). timeSlot is "HH:mm"-ish.
    // We render: "30 Apr 2026 · 14h00" for single-day,
    // and append the duration if it is set.
    final date = booking.date.trim();
    final time = booking.timeSlot.trim();
    final duration = booking.duration;
    final buf = StringBuffer();
    if (date.isNotEmpty) buf.write(date);
    if (time.isNotEmpty) {
      if (buf.isNotEmpty) buf.write(' · ');
      buf.write(time);
    }
    if (duration != null && duration > 0) {
      if (buf.isNotEmpty) buf.write(' · ');
      buf.write('${duration}min');
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    final tag = 'stripe_payment_${booking.id}';
    if (Get.isRegistered<StripePaymentController>(tag: tag)) {
      Get.delete<StripePaymentController>(tag: tag);
    }

    final controller = Get.put(
      StripePaymentController(
        booking: booking,
        totalAmount: totalAmount,
        currency: currency ??
            booking.pricing?.currency ??
            booking.sitter.currency,
      ),
      tag: tag,
    );

    final accent = _accent();

    return Scaffold(
      backgroundColor: AppColors.scaffold(context),
      appBar: AppBar(
        backgroundColor: AppColors.appBar(context),
        elevation: 0,
        scrolledUnderElevation: 0.5,
        surfaceTintColor: Colors.transparent,
        iconTheme: IconThemeData(color: accent),
        leading: const BackButton(),
        title: PoppinsText(
          text: 'payment_title'.tr,
          fontSize: 18.sp,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary(context),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(20.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSummaryCard(context, accent),
                    SizedBox(height: 20.h),
                    _buildInfoBanner(context, accent),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20.w, 0, 20.w, 20.h),
              child: Row(
                children: [
                  // Cancel (red) — left
                  Expanded(
                    child: Obx(
                      () => CustomButton(
                        title: 'common_cancel'.tr,
                        onTap: !controller.isProcessing.value
                            ? () => Get.back()
                            : null,
   